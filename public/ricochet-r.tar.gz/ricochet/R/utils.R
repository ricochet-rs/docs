#' @importFrom zeallot `%<-%`
check_dots_named <- function(dots, call = rlang::caller_env()) {
  if (!rlang::is_named2(dots)) {
    cli::cli_abort(
      "All arguments provided to {.arg ...} must be named",
      call = call
    )
  }
  invisible(dots)
}
