#' Get items associated with an API Key
#'
#' @inheritParams invoke
#' @export
get_user_items <- function(host = ricochet_host(), key = ricochet_key()) {
  check_string(key)
  check_string(host)
  resp <- httr2::request(host) |>
    httr2::req_url_path_append("api/v0/user/items") |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_method("GET") |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_perform()

  httr2::resp_body_json(resp)
}
