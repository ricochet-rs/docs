## ricochet testing! 


### Installing `ricochet`
Download the zip file. Unzip the folder. 
Enter the terminal with ricochet in the current working directory.

```shell
./ricochet
```

Confirm it is running.

Open a web browser and navigate to `localhost:6188`

Confirm the UI is working. Almost all of the navigation button wonk work.


### Installing the R package

- unzip `ricochet_0.0.0.9000.tar.gz` and build the package from source. 
- load ricochet with `library(ricochet)`
- from the `ricochet` package source directory we can publish test applications and scripts

```r
publish_shiny("test-apps/waiting")
publish_plumber("test-apps/plumb-default", "My Plumber App")
publish_plumber("test-apps/plumb-file")
```

- navigate to `localhost:6188`
- observe the new content cards
- click into one of the shiny apps or plumber apis
- press view live
- go back and press the settings cog and explore

Now to publish a schedualable content item: 

```r
res <- publish_rscript("test-apps/polls-538")
# wait a few seconds for the process to restore etc.

# now we can trigger that process to run 
invoke(res$id)
```

Ideally, `localhost:6188/content/{res$id}/settings/invocations` would have the logs but not yet.

## Notes

The account icon is the only buton that will work. You can toggle your dark mode from there. Note there is a known bug that from most pages other than the landing page the dark mode wont stick..gotta figure that out. 

You can go to `Account Settings` but only `API Keys` will be interactive. You can create an API key but it can't be used. 

