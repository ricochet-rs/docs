#' Invoke a content item
#'
#' All schedualable content items can be invoked independently
#' via REST API.
#'
#' @param id the unique ID of the content item
#' @param content_id the unique ID of the content item
#' @param key default `ricochet_key()` which fetches `RICOCHET_API_KEY` environment variable. Your API key.
#' @param host default `ricochet_host()` which fetches `RICOCHET_HOST` environment variable. The hostname of your ricochet server.
#' @export
invoke <- function(id, host = ricochet_host(), key = ricochet_key()) {
  check_string(id)
  check_string(key)
  check_string(host)
  httr2::request(host) |>
    httr2::req_url_path_append("api/v0/content", id, "invoke") |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_method("POST") |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_perform() |>
    httr2::resp_body_json()
}
