#' @export
delete_item <- function(
  id,
  host = ricochet_host(),
  key = ricochet_key()
) {
  check_string(id)
  resp <- httr2::request(ricochet_host()) |>
    httr2::req_method("DELETE") |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_url_path_append("api/v0/admin/delete", id) |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_perform()

  httr2::resp_body_json(resp)
}
