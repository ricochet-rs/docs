list_all_files <- function(include = "*", exclude = NULL, warn_env_files = TRUE) {
  check_bool(warn_env_files)

  # List all files in the current directory recursively
  all_files <- fs::dir_ls(recurse = TRUE, all = TRUE, type = "any")

  # Identify explicitly mentioned directories
  matched_dirs <- include[fs::dir_exists(include)]

  # Get *all* files inside matched directories
  extra_files <- unlist(
    lapply(
      matched_dirs,
      function(d) fs::dir_ls(d, recurse = TRUE, all = TRUE)
    )
  )

  # Convert glob patterns to regex
  glob_to_regex <- function(patterns) {
    sapply(patterns, function(p) {
      if (grepl("\\*", p)) utils::glob2rx(p) else paste0("^", p, "$")
    })
  }

  include_patterns <- glob_to_regex(include)
  exclude_patterns <- if (!is.null(exclude)) glob_to_regex(exclude) else character(0)

  # Match files against include patterns
  matched_files <- all_files[sapply(all_files, function(file) {
    any(stringr::str_detect(file, include_patterns))
  })]

  # Combine matched files and all directory contents
  res_files <- unique(c(matched_files, extra_files))

  # Apply exclusion filter
  if (length(exclude_patterns) > 0) {
    res_files <- res_files[!sapply(res_files, function(file) {
      any(stringr::str_detect(file, exclude_patterns))
    })]
  }

  fnames <- basename(res_files)

  # Warn about sensitive files
  warn_files <- c(".env", ".Renviron")
  danger_idx <- fnames %in% warn_files
  if (any(danger_idx) && warn_env_files) {
    cli::cli_alert_danger("{.file {fnames[danger_idx]}} detected! These files may contain secrets.")
    if (rlang::is_interactive()) {
      choice <- cli_menu(
        character(),
        "Do you want to continue deploying?",
        c("Yes", "No")
      )
      if (choice == 2) {
        cli::cli_alert_danger("Exiting...")
        invokeRestart("abort")
      }
    }
  }

  res_files
}
