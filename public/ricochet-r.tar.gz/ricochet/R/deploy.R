# Bundle content item into a tar.gz file
bundle_content_item <- function(path = ".", warn_env_files = TRUE) {
  check_bool(warn_env_files)
  check_string(path, allow_empty = FALSE)

  # check that the path directory even exists
  if (!dir.exists(path)) {
    cli::cli_abort("Directory does not exists {.path {path}}")
  }

  toml_fp <- file.path(path, "_ricochet.toml")

  # check that _ricochet.toml file exists
  if (!file.exists(toml_fp)) {
    create_rico_toml <- c(TRUE, FALSE)[cli_menu(
      "{cli::symbol$cross} Did not find a {.file _ricochet.toml} file.",
      "Would you like to create one now?",
      c("Yes", "No")
    )]

    # check to see if a toml file should be created
    if (!create_rico_toml) {
      cli::cli_abort(
        "A `_ricochet.toml` file is needed to deploy content items."
      )
    } else {
      use_ricochet_toml(path)
    }
  }

  # read the _ricochet.toml file
  toml_body <- tomledit::read_toml(
    file.path(path, "_ricochet.toml")
  ) |>
    tomledit::from_toml()

  # check that the language section is populated
  if (is.null(toml_body[["language"]])) {
    cli::cli_abort(
      c(
        "The `language` field is missing from the `_ricochet.toml`",
        "i" = "Try creating a new file using {.fn ricochet::use_ricochet_toml}"
      )
    )
  }

  # check that the packages file exists in the toml
  pkgs_file <- toml_body[[c("language", "packages")]]

  # check that the packages file is set in the toml
  if (is.null(pkgs_file)) {
    cli::cli_abort(
      c(
        "The language section of the `_ricochet.toml` should contain the field `packages`",
        "i" = "Try creating a new file using {.fn ricochet::use_ricochet_toml}"
      )
    )
  }

  # check that the language name is present
  if (is.null(toml_body$language$name)) {
    cli::cli_abort(
      c(
        "The language of the content item must be specified in the `_ricochet.toml`.",
        "i" = "Try creating a new file using {.fn ricochet::use_ricochet_toml}"
      )
    )
  }

  # check that the packages file exists
  if (!file.exists(file.path(path, pkgs_file))) {
    if (pkgs_file == "renv.lock") {
      cli::cli_alert_warning("An {.file renv.lock} file is required.")
      can_we_snap <- c(TRUE, FALSE)[cli_menu(
        character(),
        "Can we create one for you?",
        c("Yes", "No")
      )]

      if (!can_we_snap) {
        cli::cli_abort(
          c(
            "An {.file renv.lock} file is required to deploy R-based content.",
            "i" = "Use {.fn renv::snapshot} to create a new lockfile."
          )
        )
      }
      # create a new lockfile
      locked <- withr::with_dir(
        path,
        callr::r(
          \() renv::snapshot(),
          show = TRUE
        )
      )
    } else {
      # other files we cannot generate
      cli::cli_abort("Please generate the {.file {pkgs_file}} file.")
    }
  }

  # check if the `include` field is set
  to_include_in_bundle <- toml_body[[c("content", "include")]] %||% "*"
  to_exclude_in_bundle <- toml_body[[c("content", "exclude")]]

  # create a temp file to bundle everything into
  tmp <- tempfile(fileext = ".tar.gz")

  withr::with_dir(path, {
    include_files <- list_all_files(
      to_include_in_bundle,
      to_exclude_in_bundle,
      warn_env_files
    )

    out <- utils::tar(tmp, include_files, "gzip")

    if (out != 0) {
      cli::cli_abort("Error encountered bundling content directory.")
    }
  })

  tmp
}


# to deploy there are two conditions:
# New deployments:
# we send up the `_ricochet.toml` file
# can have env_vars
# Existing deployments:
# we check the `id` field of `_ricochet.toml` file
# and send it up

#' Deploy an item to ricochet
#'
#' @param path default `"."`. The path to your project folder.
#' @param env_vars a named list of environment variables to use along with your content item.
#' @param warn_env_vars default `TRUE`. If a file that typically contains environment variables is present, emit a warning.
#' @param host default `https://ricochet.rs`. The host of your ricochet server.
#' @param key default `ricochet_key()`. Your API key.
#' @export
deploy <- function(
  path = ".",
  env_vars = NULL,
  warn_env_vars = TRUE,
  host = ricochet_host(),
  key = ricochet_key()
) {
  # create the tar.gz
  bundle_path <- bundle_content_item(path, warn_env_vars)
  cli::cli_alert_success("Content item successfully bundled")

  toml_fp <- file.path(path, "_ricochet.toml")
  toml_body <- tomledit::read_toml(toml_fp) |>
    tomledit::from_toml()

  content_id <- toml_body[[c("content", "id")]]

  req_body <- list(
    bundle = curl::form_file(bundle_path, "application/x-tar")
  )

  # check if the `id` is set.
  if (is.null(content_id)) {
    # new content deployment
    content_type <- toml_body[[c("content", "content_type")]]
    if (is.null(content_type)) {
      cli::cli_abort(
        "Invalid {.file _ricochet.toml}. `content_type` is missing"
      )
    }
    cli::cli_alert_info("Deploying new {.code {content_type}} content item")

    req_body[["config"]] <- curl::form_file(toml_fp, "application/toml")
  } else {
    # existing content deployment
    check_string(content_id, allow_empty = FALSE)
    cli::cli_alert_info(
      "Creating a new deployment for item {.code {content_id}}"
    )
    req_body[["id"]] <- content_id
  }

  req <- httr2::request(host) |>
    httr2::req_url_path_append("api/v0/content/upload") |>
    httr2::req_body_multipart(!!!req_body) |>
    httr2::req_error(is_error = function(e) {
      FALSE
    }) |>
    httr2::req_headers(Authorization = sprintf("Key %s", key))

  # perform and exstract the body
  resp <- httr2::req_perform(req)
  res <- httr2::resp_body_json(resp)
  if (httr2::resp_is_error(resp)) {
    cli::cli_abort(res$error)
  }

  # update _ricochet.toml with ID
  toml <- tomledit::read_toml(toml_fp)
  content <- tomledit::get_item(toml, "content")
  content[["id"]] <- res$id
  tomledit::insert_items(toml, "content" = content) |>
    tomledit::write_toml(toml_fp)

  res
}
