#' Schedule a Task to run on a recurring schedule
#'
#' Refer to the [scheduling documentation](https://ricochet.rs/scheduling) for more details.
#' @param schedule a cron schedule or shorthand (`@hourly`, `@daily`, `@weekly`, `@monthly`)
#'
#' @inheritParams invoke
#' @export
schedule <- function(
  id,
  schedule,
  key = ricochet_key(),
  host = ricochet_host()
) {
  check_string(id)
  check_string(key)
  check_string(schedule)
  httr2::request(host) |>
    httr2::req_url_path_append("api/v0/content", id, "schedule") |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_method("PATCH") |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_body_json(list(schedule = schedule)) |>
    httr2::req_perform() |>
    httr2::resp_body_json()
}
