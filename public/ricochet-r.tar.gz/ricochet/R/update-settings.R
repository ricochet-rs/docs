#' Update individual content settings
#'
#' Use `update_settings()` to update individual settings for your content item
#' such as the name, access type, or slug.
#'
#' @inheritParams invoke
#' @param ... named settings to update corresponding to the settings in the `_ricochet.toml`.
#' @details
#'
#' `update_settings()` allows you to update `content`, `static`, or `serve` settings. For more on the possible settings [see the documentation](https://docs.ricochet.rs/ricochet-toml).
#'
#' ## Content settings
#'
#' The following content settings can be modified:
#'
#' - `name`
#' - `slug`
#' - `entrypoint`
#' - `access_type`
#' - `content_type`
#' - `summary`
#' - `thumbnail`
#' - `tags`
#'
#' ## Serve settings
#'
#' The following service settings can be modified:
#'
#' - `min_instances`
#' - `max_instances`
#' - `spawn_threshold`
#' - `max_connections`
#' - `max_connection_age`
#'
#' ## Static settings
#'
#' The following static html site settings can be modified:
#'
#' - `index`
#' - `output_dir`
#'
#' @returns a `Toml` item of the new
#'
#' @examples
#' \dontrun{
#' update_settings(
#'   "01JV7KJPREMT1JKC1PBNF0GGVP",
#'   content = list(name = "New content name", slug = "my-new-slug")
#' )
#' }
update_settings <- function(
  id,
  ...,
  host = ricochet_host(),
  key = ricochet_key()
) {
  check_string(id)
  # extract the settings
  settings <- rlang::list2(...)
  # ensure that theyre all named
  check_dots_named(settings)

  resp <- httr2::request(host) |>
    httr2::req_url_path_append("api/v0/content", id, "settings") |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_method("PATCH") |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_body_json(settings) |>
    httr2::req_perform() |>
    httr2::resp_body_string() |>
    tomledit::parse_toml()
  cli::cli_alert_success(
    "Please update {.file _ricochet.toml} with new settings {intToUtf8(0x1F447)}"
  )
  resp
}
