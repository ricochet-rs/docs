#' Create a `_ricochet.toml`
#'
#' @param path default `"."`. The directory containing the item to deploy.
#' @export
use_ricochet_toml <- function(path = ".") {
  name <- cli_prompt(
    "{cli::symbol$arrow_right} Give your content item a brief, descriptive name:",
    prompt = "Name: "
  )

  access_type <- c("private", "internal", "external")[cli_menu(
    "\n",
    "{cli::symbol$arrow_right} Who should have access to this content?",
    c("Private", "Internal", "External"),
    default_choice = 1L
  )]

  content_types <- c(
    "Plumber" = "plumber",
    "Shiny" = "shiny",
    "Ambiorix" = "ambiorix",
    "R Script" = "r",
    "Quarto" = "quarto-r",
    "RMarkdown" = "rmd",
    "Julia Script" = "julia",
    "Julia Service" = "julia-service",
    "Serverless R" = "serverless-r"
  )

  content_type <- cli_menu(
    "\n",
    "{cli::symbol$arrow_right} What type of item are you deploying?",
    names(content_types),
  )

  content_type <- content_types[content_type]

  # if the content type is Quarto or RMarkdown we need to check if
  # a shiny runtime is needed
  if (content_type %in% c("rmd", "quarto-r")) {
    # ask if they are using a Shiny runtime?
    needs_shiny <- c(TRUE, FALSE)[cli_menu(
      "\n",
      "{cli::symbol$continue} Is a Shiny runtime required?",
      c("Yes", "No")
    )]

    if (needs_shiny) {
      content_type <- paste0(content_type, "-shiny")
    }
  }

  # for ambiorix, r, shiny, we check for .R extensions
  # for quarto-r / quarto-r-shiny we check for .qmd extension
  # for rmd / rmd-shiny we check for .qmd extension
  ext_regex <- switch(
    content_type,
    "r" = "\\.r$|\\.R$",
    "julia" = "\\.jl$",
    "shiny" = "\\.r$|\\.R$",
    "plumber" = "\\.r$|\\.R$",
    "ambiorix" = "\\.r$|\\.R$",
    "quarto-r" = "\\.qmd$",
    "quarto-r-shiny" = "\\.qmd$",
    "rmd" = "\\.rmd$|\\.Rmd$",
    "rmd-shiny" = "\\.rmd$|\\.Rmd$",
    "serverless-r" = "\\.r$|\\.R$"
  )

  path <- normalizePath(path)

  entrypoint_candidates <- list.files(
    path,
    pattern = ext_regex,
    recursive = TRUE,
    full.names = TRUE
  )

  # check if any entrypoint candidates exist, if not we
  # invoke an error
  if (length(entrypoint_candidates) == 0) {
    cli::cli_abort(
      c(
        "No candidate entrypoint files found.",
        "i" = "The {.code {content_type}} content type requires an entrypoint that matches the pattern {.code {ext_regex}}"
      )
    )
  }

  # remove prepended path
  entrypoint_candidates <- gsub(file.path(path, ""), "", entrypoint_candidates)

  # make pretty labels for the entrypoints
  candidate_labels <- unlist(
    lapply(
      entrypoint_candidates,
      function(.f) {
        cli::cli_fmt(cli::cli_text("{.file {(.f)}}"))
      }
    )
  )

  entrypoint <- entrypoint_candidates[cli_menu(
    "\n",
    "{cli::symbol$arrow_right} Select the file that will start your content:",
    candidate_labels,
  )]

  # ensure that Manifest.toml and Project.toml are present for julia
  language <- if (content_type == "julia") {
    list(
      name = "julia",
      packages = "Manifest.toml"
    )
  } else {
    list(
      name = "r",
      packages = "renv.lock"
    )
  }

  toml <- tomledit::toml(
    content = list(
      name = name,
      entrypoint = entrypoint,
      access_type = access_type,
      content_type = content_type
    ),
    language = language
  )

  if (content_type %in% c("rmd", "quarto-r")) {
    is_static <- c(TRUE, FALSE)[cli_menu(
      "\n",
      "{cli::symbol$arrow_right} Do you want to serve your item as a website?",
      c("Yes", "No")
    )]

    if (is_static) {
      static_settings <- static_settings_prompt(path, entrypoint)
      toml <- tomledit::insert_items(toml, static = static_settings)
    }
  }

  is_servable <- content_type %in%
    c("rmd-shiny", "quarto-r-shiny", "ambiorix", "shiny", "plumber")

  # if the content has a runtime then we insert the default settings
  if (is_servable) {
    toml <- tomledit::insert_items(
      toml,
      serve = list(
        min_instances = 0L,
        max_instances = 5L,
        spawn_threshold = 80L,
        max_connections = 10L
      )
    )
  }

  # we begin to write the _ricochet.toml file
  rico_fp <- file.path(path, "_ricochet.toml")

  if (file.exists(rico_fp)) {
    overwrite <- c(TRUE, FALSE)[cli_menu(
      "\n",
      c(
        "x" = "{.file _ricochet.toml} already exists.",
        "Do you want to overwrite this file?"
      ),
      c("Yes", "No")
    )]

    if (!overwrite) {
      cli::cli_alert_danger("Exiting...")
      invokeRestart("abort")
    }
  }

  tomledit::write_toml(
    toml,
    rico_fp
  )
  cat(tomledit::to_toml(toml))
  cli::cli_alert_success("{.file _ricochet.toml} successfully written!")
  invisible(toml)
}


cli_prompt <- function(header, prompt = "> ") {
  cli::cli_inform(header)

  repeat {
    name <- cli_readline(prompt)

    if (name == "0") {
      cli::cli_alert_danger("Exiting...")
      if (rlang::is_interactive()) {
        invokeRestart("abort")
      } else {
        cnd <- rlang::error_cnd(message = "User exited prompt")
        rlang::cnd_signal(cnd)
      }
    }
    if (nzchar(name)) {
      break
    } else {
      cli::cli_alert_info("Please enter a brief name or press 0 to exit.")
    }
  }
  name
}


# adapted and mangled from https://github.com/r-lib/gargle/blob/main/R/utils-ui.R
cli_menu <- function(
  header,
  prompt,
  choices,
  default_choice = NULL,
  exit = integer(),
  .envir = rlang::caller_env(),
  error_call = rlang::caller_env()
) {
  check_number_whole(default_choice, allow_null = TRUE)

  choice_labels <- paste0(
    cli::style_bold(seq_along(choices)),
    ": ",
    choices
  )

  if (!is.null(default_choice)) {
    choice_labels[default_choice] <- paste0(
      choice_labels[default_choice],
      " (default)"
    )
  }

  cli::cli_inform(
    c(header, prompt, choice_labels),
    .envir = .envir
  )

  if (!is.null(default_choice)) {
    cli::cli_alert_info("Press enter to use the default.")
  }

  repeat {
    selected <- cli_readline("Selection: ")
    if (selected %in% c("0", seq_along(choices))) {
      break
    }

    # if empty and there is a default choice use that
    if (selected == "" && !is.null(default_choice)) {
      selected <- as.integer(default_choice)
      break
    }

    cli::cli_inform(
      "Enter a number between 1 and {length(choices)}, or enter 0 to exit."
    )
  }

  selected <- as.integer(selected)

  if (selected %in% c(0, exit)) {
    if (!rlang::is_interactive()) {
      cli::cli_abort("Exiting...", call = NULL)
    } else {
      cli::cli_alert_danger("Exiting...")
      # simulate user pressing Ctrl + C
      invokeRestart("abort")
    }
  }

  selected
}

cli_readline <- function(prompt) {
  local_input <- getOption("cli_input", character())

  # not convinced that we need to plan for multiple mocked inputs, but leaving
  # this feature in for now
  if (length(local_input) > 0) {
    input <- local_input[[1]]
    cli::cli_inform(paste0(prompt, input))
    options(cli_input = local_input[-1])
    input
  } else {
    readline(prompt)
  }
}
