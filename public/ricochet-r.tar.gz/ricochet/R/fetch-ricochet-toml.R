#' Get the latest `_ricochet.toml` file
#'
#' It is possible to update settings for a content item via the UI.
#' In this case, the `_ricochet.toml` file will become out of sync with your
#' local file.
#'
#' `get_ricochet_toml()` will fetch the associated `_ricochet.toml` file for a content item.
#'
#' @inheritParams invoke
#' @rdname toml
#' @export
get_ricochet_toml <- function(
  id,
  host = ricochet_host(),
  key = ricochet_key()
) {
  check_string(id)
  check_string(key)
  check_string(host)
  httr2::request(host) |>
    httr2::req_url_path_append("api/v0/content", id, "toml") |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_method("GET") |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_body_json(list(schedule = schedule)) |>
    httr2::req_perform() |>
    httr2::resp_body_string() |>
    tomledit::parse_toml()
}
