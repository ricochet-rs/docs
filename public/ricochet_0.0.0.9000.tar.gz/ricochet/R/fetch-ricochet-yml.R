#' Get the latest `_ricochet.yml` file 
#' 
#' It is possible to update settings for a content item via the ui.
#' In this case, the `_ricochet.yml` file gets out of sync with your
#' local file. 
#' 
#' This function will fetch your `_ricochet.yml` file for you.
#' 
#' @export
get_ricochet_yml <- function(id, destination = NULL) {
  check_string(id)
  check_string(destination, allow_null = TRUE)

  ricochet_yml <- httr2::request(ricochet_host()) |>
    httr2::req_url_path_append("/api/v0/content", id, "settings") |> 
    httr2::req_perform() |> 
    httr2::resp_body_string() 

  cli::cli_inform("Latest {.file _ricochet.yml}:")
  cli::cli_rule()
  cli::cat_line(ricochet_yml)
  invisible(yaml::yaml.load(ricochet_yml))
}

