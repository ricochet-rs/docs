#' Encrypts environment variables
#' @examples
#' env_vars <- list(
#'   "api_key" = "fbivyb137294hgwv",
#'   "hello" = "world",
#'   "current_user" = "josiah@parry.com"
#' )
#' encrypt_env_vars(!!!env_vars)
#' @noRd
#' @keywords internal
encrypt_env_vars <- function(
  ...,
  host = ricochet_host(),
  error_call = rlang::caller_call()
) {
  # validte the dots provide
  env_vars <- validate_dots_named(...)

  # get the public key to encrypt with
  ricochet_pub_key <- httr2::request(host) |>
    httr2::req_url_path_append("/api/v0/public-key") |>
    httr2::req_perform() |>
    httr2::resp_body_string() |>
    openssl::read_pubkey()

  # create resultant vectors
  res_vals <- vector("list", length(env_vars))
  res_keys <- vector("character", length(env_vars))

  # get the names
  env_names <- names(env_vars)

  # iterate through k-v pairs
  for (i in seq_along(env_vars)) {
    k <- env_names[[i]]
    v <- env_vars[[i]]
    check_string(v, call = error_call)

    # encrypt and base64 encode using the ricochet public key
    k_encrypted <- b64::encode(openssl::rsa_encrypt(
      charToRaw(k),
      ricochet_pub_key
    ))
    v_encrypted <- b64::encode(openssl::rsa_encrypt(
      charToRaw(v),
      ricochet_pub_key
    ))
    res_keys[i] <- k_encrypted
    res_vals[[i]] <- v_encrypted
  }

  rlang::set_names(res_vals, res_keys)
}


validate_dots_named <- function(..., error_call = rlang::caller_call()) {
  dots <- rlang::list2(...)
  if (!rlang::is_named2(dots)) {
    cli::cli_abort(
      "All arguments provided to {.arg ...} must be named",
      call = error_call
    )
  }
  dots
}
