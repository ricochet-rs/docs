#' @export
#' @rdname invoke
get_active_invocations <- function(
  id,
  host = ricochet_host(),
  key = ricochet_key()
) {
  check_string(id)
  check_string(host)
  check_string(key)
  res <- httr2::request(host) |>
    httr2::req_url_path_append("api/v0/content", id, "invocations", "active") |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_method("GET") |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_perform() |>
    httr2::resp_body_json()

  do.call(rbind.data.frame, res)
}

#' @param invocation_id the `ulid` of the invocation to be stopped. See `get_active_invocations()` to list invocation IDs.
#' @rdname invoke
#' @export
stop_invocation <- function(
  content_id,
  invocation_id,
  host = ricochet_host(),
  key = ricochet_key()
) {
  check_string(content_id)
  check_string(invocation_id)
  check_string(host)
  check_string(key)
  res <- httr2::request(host) |>
    httr2::req_url_path_append(
      "api/v0/content",
      content_id,
      "invocations",
      invocation_id,
      "stop"
    ) |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_method("POST") |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_perform() |>
    httr2::resp_body_json()
}
