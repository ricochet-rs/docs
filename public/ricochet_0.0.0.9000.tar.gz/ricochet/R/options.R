#' Determine ricochet host
#'
#' If the environment variable `RICOCHET_HOST` is set, that is used.
#' If not, the option `ricochet.host` is fetched. If that is also empty,
#' the default value is `"http://localhost:3000"`
#' @export
ricochet_host <- function() {
  host <- Sys.getenv("RICOCHET_HOST")
  if (!nzchar(host)) {
    host <- getOption("ricochet.host", "https://ricochet.rs")
  }
  host
}

ricochet_key <- function(key = Sys.getenv("RICOCHET_API_KEY")) {
  check_string(key)
  if (key == "") {
    NULL
  } else {
    key
  }
}
