#' List and stop service instances
#'
#' @inheritParams invoke
#' @rdname instances
#' @export
list_instances <- function(
  id,
  host = ricochet_host(),
  key = ricochet_key()
) {
  check_string(id)
  check_string(host)
  check_string(key)
  res <- httr2::request(host) |>
    httr2::req_url_path_append("api/v0/content", id, "instances") |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_perform() |>
    httr2::resp_body_json()

  do.call(rbind.data.frame, res)
}

#' @param pid the process ID of the service instance to stop
#' @rdname instances
#' @export
stop_instance <- function(
  id,
  instance_id,
  host = ricochet_host(),
  key = ricochet_key()
) {
  check_string(id)
  check_string(host)
  check_string(key)
  check_string(instance_id)
  httr2::request(host) |>
    httr2::req_url_path_append(
      "api/v0/content",
      id,
      "instances",
      instance_id,
      "stop"
    ) |>
    httr2::req_error(is_error = function(e) FALSE) |>
    httr2::req_method("POST") |>
    httr2::req_headers(Authorization = sprintf("Key %s", key)) |>
    httr2::req_perform() |>
    httr2::resp_body_json()
}
