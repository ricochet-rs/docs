#' Determine ricochet host & key
#'
#' @param host default `RICOCHET_HOST` environment variable. The host URL of the ricochet server. The default value is `"https://dev.ricochet.rs"`
#' @param key default `RICOCHET_API_KEY` environment variable. An API Key to be used when interacting with ricochet.
#' @export
#' @rdname ricochet
ricochet_host <- function(host = Sys.getenv("RICOCHET_HOST")) {
  check_string(host)
  if (!nzchar(host)) {
    host <- getOption("ricochet.host", "https://dev.ricochet.rs")
  }
  host
}
#' @export
#' @rdname ricochet
ricochet_key <- function(key = Sys.getenv("RICOCHET_API_KEY")) {
  check_string(key)
  if (key == "") {
    NULL
  } else {
    key
  }
}
