static_settings_prompt <- function(path, entrypoint) {
  check_string(entrypoint, allow_empty = FALSE)

  all_dirs <- list.dirs(path, recursive = FALSE)
  base_dir_names <- basename(all_dirs)
  known_out_dirs <- c("_book", "_site", "_manuscript")

  opts <- c(
    "Infer",
    base_dir_names[base_dir_names %in% known_out_dirs],
    "Enter manually"
  )

  out_dir <- opts[cli_menu(
    "\n",
    "{cli::symbol$arrow_right} Where is your site rendered?",
    opts,
    1
  )]


  if (out_dir == "Enter manually") {
    out_dir <- cli_prompt("{cli::symbol$continue} Which directory is your site rendered to?", "Directory: ")
  } else if (out_dir == "Infer") {
    out_dir <- NA
  }

  # which HTML file should be served?
  ep_html <- paste0(tools::file_path_sans_ext(entrypoint), ".html")

  opts <- unique(c("Infer", "index.html", ep_html, "Enter manually"))
  default_opt <- if (is.na(out_dir)) {
    which(opts == "Infer")
  } else {
    NULL
  }

  index_html <- opts[cli_menu("\n", "Which html file should be served?", opts, default_opt)]

  if (index_html == "Enter manually") {
    index_html <- cli_readline("Filename: ")

    if (tools::file_ext(index_html) != "html") {
      repeat {
        cli::cli_alert_info("The file must have the `.html` extension or enter 0 to exit.")
        selected <- cli_readline("Filename : ")
        if (tools::file_ext(selected) == "html") {
          index_html <- selected
          break
        } else if (selected == 0) {
          cli::cli_alert_danger("Exiting...")
          invokeRestart("abort")
        }
      }
    }
  } else if (index_html == "Infer") {
    index_html <- NA
  }


  list(
    output_dir = out_dir,
    index = index_html
  )
}

# index, output_dir, render_fn

# we can check if the following directories exist:
# _book, _site, _manuscript
# if not, we assume the current working directory or ask them to provide a directory name
